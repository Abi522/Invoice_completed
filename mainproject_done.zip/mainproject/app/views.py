# views.py
from rest_framework import viewsets
from rest_framework.response import Response
from .models import Invoice, Invoice_Detail
from .serializers import InvoiceSerializer, Invoice_DetailSerializer

class InvoiceViewSet(viewsets.ModelViewSet):
    queryset = Invoice.objects.all()
    serializer_class = InvoiceSerializer


class Invoice_DetailViewSet(viewsets.ModelViewSet):
    queryset = Invoice_Detail.objects.all()
    serializer_class = Invoice_DetailSerializer


