from rest_framework import serializers
from .models import Invoice
from .models import  Invoice_Detail

"""class InvoiceSerializer(serializers.ModelSerializer):

    class Meta:
        model = Invoice
        fields = "__all__"

class Invoice_DetailSerializer(serializers.ModelSerializer):

    class Meta:
        model = Invoice_Detail
        fields = "__all__"
"""
class InvoiceSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Invoice
        fields = '__all__'

class Invoice_DetailSerializer(serializers.ModelSerializer):


    class Meta:
        model = Invoice_Detail
        fields = '__all__'








# views.py
from rest_framework import viewsets
from rest_framework.response import Response
from .models import Invoice_Detail
from .serializers import Invoice_DetailSerializer
